// record using this: https://stackoverflow.com/a/62865574/6688750


function spawnWalker(x, y, spacing, offset) {
  this.currX = x;
  this.currY = y;
  
  this.col = random(['green','blue']) //random(palette)

  this.spacing = spacing;
  this.offset = offset;

  this.path = []; // this will help remember the path
  this.drawnPath = [];

  this.advance = function (grid) {


    // move and update position
    opts = this.getOptions(grid);
    choice = random(opts);

    if(choice){
      // add current position to the path array
      this.path.push({ dx: this.currX, dy: this.currY });
      this.drawnPath.push({ dx: this.currX, dy: this.currY });

      this.currX = choice.dx;
      this.currY = choice.dy;

      return {dx: this.currX, dy: this.currY}
    }else if(this.path.length>0){
      backtracked = this.path.pop()
      
      this.currX = backtracked.dx
      this.currY = backtracked.dy
    }
  };

  this.getOptions = function (grid) {

    options = [];
    if (this.currX > 0) {
      if (grid[this.currX - 1][this.currY]) {
        options.push({ dx: this.currX - 1, dy: this.currY });
      }
    }

    if (this.currY > 0) {
      if (grid[this.currX][this.currY - 1]) {
        options.push({ dx: this.currX, dy: this.currY - 1 });
      }
    }

    if (this.currX < grid.length - 2) {
      if (grid[this.currX + 2][this.currY]) {
        options.push({ dx: this.currX + 2, dy: this.currY });
      }
    }

    if (this.currY < grid[0].length - 1) {
      if (grid[this.currX][this.currY + 1]) {
        options.push({ dx: this.currX, dy: this.currY + 1 });
      }
    }

    return options;
  };
  this.display = function (g) {
    for (let n = 0; n < this.drawnPath.length - 1; n++) {
      
      d = dist(this.drawnPath[n].dx * this.spacing + this.offset,
        this.drawnPath[n].dy * this.spacing + this.offset,
        this.drawnPath[n + 1].dx * this.spacing + this.offset,
        this.drawnPath[n + 1].dy * this.spacing + this.offset)
      
      if(d==this.spacing || d==this.spacing*2){
      
        
      if(this.col == 'blue'){
        stroke(250,150,0,150)
      }else if(this.col == 'green'){
        stroke(150,250,0,50)
      }
      strokeWeight(spacing/5);
        line(
        this.drawnPath[n].dx * this.spacing + this.offset,
        this.drawnPath[n].dy * this.spacing + this.offset,
        this.drawnPath[n + 1].dx * this.spacing + this.offset,
        this.drawnPath[n + 1].dy * this.spacing + this.offset
      );
      stroke(150,0,0,50)
      strokeWeight(spacing/3);
      line(
        this.drawnPath[n].dx * this.spacing + this.offset + shdwOfst,
        this.drawnPath[n].dy * this.spacing + this.offset + shdwOfst,
        this.drawnPath[n + 1].dx * this.spacing + this.offset + shdwOfst,
        this.drawnPath[n + 1].dy * this.spacing + this.offset + shdwOfst
      );
        

 
        
        
      }
    }
  };
}

function makeGrid(w, h, spacing, offset) {
  this.w = w;
  this.h = h;
  this.spacing = spacing;
  this.offset = offset;
  this.grid = [];

  this.initGrid = function () {
    for (let x = this.offset; x < this.w - this.offset; x += this.spacing) {
      row = [];
      for (let y = this.offset; y < this.h - this.offset; y += this.spacing) {
        row.push(1);
      }
      this.grid.push(row);
    }
  };

  this.display = function () {

    for (let i = 0; i < this.grid.length; i++) {
      for (let j = 0; j < this.grid[0].length; j++) {
        if (this.grid[i][j]) {
          //point(i * this.spacing + this.offset, j * this.spacing + this.offset);
        }
      }
    }
  };
}

function gridHandler(grid, randomWalkers){
  this.grid = grid // the grid
  this.randomWalkers = [...randomWalkers]  // an array of random walkers

  // go through and set their starting positions in the grid to false
  for(let n = 0; n<this.randomWalkers.length; n++){
      this.grid.grid[randomWalkers[n].currX][randomWalkers[n].currY] = 0
  }

  // advance entire board state
  // checks off cells that have paths in them
  this.advanceGrid = function(){

    // go through all the random walkers and advance each one individually
    for(let n = 0; n<this.randomWalkers.length; n++){
      toCheck = this.randomWalkers[n].advance(this.grid.grid)

      if(toCheck){
        this.grid.grid[toCheck.dx][toCheck.dy] = 0
      }
    }
  }

  this.display = function(){
    this.grid.display()
    for(let n = 0; n<this.randomWalkers.length; n++){
      this.randomWalkers[n].display()
    }
  }
}

function setup() {
  palette = ["#454d66", "#309975", "#58b368", "#dad873", "#efeeb4", "#1f306e", "#553772", "#8f3b76", "#c7417b", "#f5487f"]
  
  //palette = ["#007f5f","#2b9348","#55a630","#80b918","#aacc00","#bfd200","#d4d700","#dddf00","#eeef20","#ffff3f"]


  w = min(windowWidth, windowHeight);
  wx = w/0.8;
  wy = w/2;
  createCanvas(wx, wy);

  spacing = 6
  offset = 8

  strokeWeight(spacing/3);
  shdwOfst = spacing/2
  
  g = new makeGrid(wx, wy, spacing, offset);
  g.initGrid();

  r = new spawnWalker(0,0, spacing, offset)
  r2 = new spawnWalker(g.grid.length-1,g.grid[0].length-1, spacing, offset)
  r3 = new spawnWalker(g.grid.length-1,0, spacing, offset)
  r4 = new spawnWalker(0,g.grid[0].length-1, spacing, offset)

  h = new gridHandler(g, [r,r2,r3,r4])
  
  bkCol = palette[9]
}

function draw() {
  blendMode(BLEND)
  background(150,0,0,10);
  blendMode(ADD)
  stroke(0);
  
  if(frameCount>100){
  h.display()
  h.advanceGrid()
  }
}